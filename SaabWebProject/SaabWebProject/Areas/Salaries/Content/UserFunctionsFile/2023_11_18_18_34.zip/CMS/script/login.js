const loginUsernameInput = document.querySelector('.login-box__username')
const loginPasswordInput = document.querySelector('.login-box__password')
const loginUsernameInputLabel = document.querySelector('.login-box__input-username-label')
const loginPasswordInputLabel = document.querySelector('.login-box__input-password-label')
const loginIconPasswordLock = document.querySelector('.login-box__icon-password-lock')
const loginIconPasswordUnlock = document.querySelector('.login-box__icon-password-unlock')

loginUsernameInput.addEventListener('focus',()=>{
    loginUsernameInputLabel.classList.add('active')
})
loginUsernameInput.addEventListener('blur',()=>{
    if (loginUsernameInput.value === ''){
        loginUsernameInputLabel.classList.remove('active')
    }
})
loginPasswordInput.addEventListener('focus',()=>{
    loginPasswordInputLabel.classList.add('active')
})
loginPasswordInput.addEventListener('blur',()=>{
    if (loginPasswordInput.value === ''){
        loginPasswordInputLabel.classList.remove('active')
    }
})

loginIconPasswordLock.addEventListener('click',()=>{
    loginIconPasswordLock.style.display = 'none'
    loginIconPasswordUnlock.style.display = 'block'
    loginPasswordInput.type='text'
})
loginIconPasswordUnlock.addEventListener('click',()=>{
    loginIconPasswordUnlock.style.display = 'none'
    loginIconPasswordLock.style.display = 'block'
    loginPasswordInput.type='password'
})