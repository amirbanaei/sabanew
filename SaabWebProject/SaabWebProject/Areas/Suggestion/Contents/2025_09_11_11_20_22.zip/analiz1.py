import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import lagrange, CubicSpline
from sympy import symbols, lambdify, sympify, diff, simplify, pprint

def get_function(expr_str):
    x = symbols('x')
    expr = sympify(expr_str)
    func = lambdify(x, expr, 'numpy')
    return func, expr

def newton_interpolation(x_vals, y_vals):
    n = len(x_vals)
    coef = np.copy(y_vals)
    for j in range(1, n):
        coef[j:n] = (coef[j:n] - coef[j-1:n-1]) / (x_vals[j:n] - x_vals[0:n-j])
    
    def newton_poly(x):
        result = coef[0]
        for i in range(1, n):
            term = coef[i]
            for j in range(i):
                term *= (x - x_vals[j])
            result += term
        return result
    return newton_poly

def newton_symbolic(x_vals, y_vals):
    x = symbols('x')
    n = len(x_vals)
    coef = np.copy(y_vals)
    for j in range(1, n):
        coef[j:n] = (coef[j:n] - coef[j-1:n-1]) / (x_vals[j:n] - x_vals[0:n-j])
    
    poly = coef[0]
    for i in range(1, n):
        term = coef[i]
        for j in range(i):
            term *= (x - x_vals[j])
        poly += term
    poly = simplify(poly)
    return poly

def lagrange_symbolic(x_vals, y_vals):
    x = symbols('x')
    n = len(x_vals)
    poly = 0
    for i in range(n):
        term = y_vals[i]
        for j in range(n):
            if j != i:
                term *= (x - x_vals[j]) / (x_vals[i] - x_vals[j])
        poly += term
    poly = simplify(poly)
    return poly

def print_spline_coefficients(spline, name):
    print(f"\nضریب‌های اسپلاین {name}:")
    c = spline.c
    intervals = list(zip(spline.x[:-1], spline.x[1:]))
    for i, (a, b, cc, d) in enumerate(zip(*c)):
        x0, x1 = intervals[i]
        print(f"بازه [{x0}, {x1}]:")
        print(f"  S(x) = {a} + {b}(x - {x0}) + {cc}(x - {x0})^2 + {d}(x - {x0})^3")

def plot_all(fx, x_vals, lag_poly, newton_poly, spline_nat, spline_clamped):
    plt.rcParams['font.family'] = 'DejaVu Sans'
    plt.rcParams['font.sans-serif'] = ['Tahoma']
    
    x_dense = np.linspace(min(x_vals), max(x_vals), 1000)
    f_real = fx(x_dense)

    plt.figure(figsize=(14, 8))

    plt.subplot(2, 1, 1)
    plt.plot(x_dense, f_real, label='تابع اصلی f(x)', linewidth=2)
    plt.plot(x_dense, lag_poly(x_dense), label='لاگرانژ')
    plt.plot(x_dense, newton_poly(x_dense), label='نیوتن')
    plt.plot(x_dense, spline_nat(x_dense), label='اسپلاین طبیعی')
    plt.plot(x_dense, spline_clamped(x_dense), label='اسپلاین مقید')
    plt.scatter(x_vals, fx(x_vals), color='black')
    plt.legend()
    plt.title('نمودار توابع و درون‌یابی‌ها')
    plt.grid(True)

    plt.subplot(2, 1, 2)
    plt.plot(x_dense, np.abs(f_real - lag_poly(x_dense)), label='خطای لاگرانژ')
    plt.plot(x_dense, np.abs(f_real - newton_poly(x_dense)), label='خطای نیوتن')
    plt.plot(x_dense, np.abs(f_real - spline_nat(x_dense)), label='خطای اسپلاین طبیعی')
    plt.plot(x_dense, np.abs(f_real - spline_clamped(x_dense)), label='خطای اسپلاین مقید')
    plt.legend()
    plt.title('نمودار خطاهای درون‌یابی')
    plt.grid(True)

    plt.tight_layout()
    plt.show()

def main():
    try:
        expr_str = input("ضابطه تابع f(x) را وارد کنید (مثلاً sin(x)): ")
        x_vals = list(map(float, input("نقاط متمایز x را با فاصله وارد کنید (مثلاً 0 1 2 3): ").split()))
        
        if len(x_vals) != len(set(x_vals)):
            print("نقاط باید متمایز باشند!")
            return

        fx, expr = get_function(expr_str)
        y_vals = fx(np.array(x_vals))

        lag_poly = lagrange(x_vals, y_vals)
        newton_poly = newton_interpolation(np.array(x_vals), np.array(y_vals))
        spline_nat = CubicSpline(x_vals, y_vals, bc_type='natural')

        f_prime = lambdify(symbols('x'), diff(expr, symbols('x')), 'numpy')
        spline_clamped = CubicSpline(
            x_vals,
            y_vals,
            bc_type=((1, f_prime(x_vals[0])), (1, f_prime(x_vals[-1])))
        )

        print("\nچندجمله‌ای درون‌یاب لاگرانژ:")
        pprint(lagrange_symbolic(x_vals, y_vals))

        print("\nچندجمله‌ای درون‌یاب نیوتن:")
        pprint(newton_symbolic(np.array(x_vals), np.array(y_vals)))

        print_spline_coefficients(spline_nat, "طبیعی")
        print_spline_coefficients(spline_clamped, "مقید")

        plot_all(fx, np.array(x_vals), lag_poly, newton_poly, spline_nat, spline_clamped)

    except Exception as e:
        print(f"خطا: {e}")

if __name__ == "__main__":
    main()